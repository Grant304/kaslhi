; One-click installer build for the current SPORTSDESK release.
#define AppName "SPORTSDESK"
#define AppVersion "2.3.0"
#define AppPublisher "Bankroll Builder"
#define AppSource "C:\Users\Owner\Desktop\SPORTSDESK\SPORTSDESK"

[Setup]
AppId={{8C54BEFC-87C2-465C-9E1F-043F43649AAC}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\SPORTSDESK
DefaultGroupName=SPORTSDESK
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=.
OutputBaseFilename=SPORTSDESK-Setup
SetupIconFile={#AppSource}\Assets\SPORTSDESK.ico
UninstallDisplayIcon={app}\SPORTSDESK.exe
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "{#AppSource}\SPORTSDESK.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\SPORTSDESK.exe.config"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\Microsoft.Web.WebView2.Core.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\Microsoft.Web.WebView2.WinForms.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\WebView2Loader.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\WebView2-LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#AppSource}\Assets\SPORTSDESK.ico"; DestDir: "{app}\Assets"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\SPORTSDESK"; Filename: "{app}\SPORTSDESK.exe"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\SPORTSDESK.ico"
Name: "{autodesktop}\SPORTSDESK"; Filename: "{app}\SPORTSDESK.exe"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\SPORTSDESK.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\SPORTSDESK.exe"; Description: "Launch SPORTSDESK"; Flags: nowait postinstall skipifsilent
