; SPORTSDESK Windows installer — Inno Setup 6
; Put this file beside the SPORTSDESK application folder, then open it in Inno Setup and press Build > Compile.

#define AppName "SPORTSDESK"
#define AppVersion "2.3.0"
#define AppPublisher "Bankroll Builder"
#define AppExeName "SPORTSDESK.exe"

[Setup]
AppId={{8C54BEFC-87C2-465C-9E1F-043F43649AAC}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\SPORTSDESK
DefaultGroupName=SPORTSDESK
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=Installer
OutputBaseFilename=SPORTSDESK-Setup-{#AppVersion}-x64
SetupIconFile=SPORTSDESK\Assets\SPORTSDESK.ico
UninstallDisplayIcon={app}\{#AppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "SPORTSDESK\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\SPORTSDESK"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\SPORTSDESK.ico"
Name: "{autodesktop}\SPORTSDESK"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\SPORTSDESK.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch SPORTSDESK"; Flags: nowait postinstall skipifsilent

